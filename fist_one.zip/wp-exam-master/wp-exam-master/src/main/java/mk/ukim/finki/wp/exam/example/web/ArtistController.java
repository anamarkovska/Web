package mk.ukim.finki.wp.exam.example.web;

import mk.ukim.finki.wp.exam.example.model.Album;
import mk.ukim.finki.wp.exam.example.model.Artist;
import mk.ukim.finki.wp.exam.example.model.Song;
import mk.ukim.finki.wp.exam.example.model.exceptions.AlbumNotFound;
import mk.ukim.finki.wp.exam.example.model.exceptions.ArtistNotFound;
import mk.ukim.finki.wp.exam.example.model.exceptions.SongNotFound;
import mk.ukim.finki.wp.exam.example.service.AlbumService;
import mk.ukim.finki.wp.exam.example.service.ArtistService;
import mk.ukim.finki.wp.exam.example.service.SongServce;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/artists")
public class ArtistController {

    private final ArtistService service;
    private final SongServce songServce;
    private final AlbumService albumService;

    public ArtistController(ArtistService service, SongServce songServce, AlbumService albumService) {
        this.service = service;
        this.songServce = songServce;
        this.albumService = albumService;
    }


    @GetMapping
    public String showArtists(@RequestParam(required = false) String error, Model model) {
        if (error != null && !error.isEmpty()) {
            model.addAttribute("hasError", true);
            model.addAttribute("error", error);
        }
        List<Artist> artists = this.service.listAllArtists();
        model.addAttribute("artists", artists);
        return "list.html";
    }

    @GetMapping("/{id}")
    public String showArtist(@PathVariable Long id, Model model) {
        Artist artist=this.service.findById(id).orElseThrow(ArtistNotFound::new);
        model.addAttribute("artist", artist);
        List<Song> songs=artist.getSong();
        model.addAttribute("songs", songs);
        List<Album>albums=artist.getAlbum();
        model.addAttribute("albums", albums);
        return "artist.html";
    }

    @GetMapping("/album/{id}")
    public String showAlbums(@PathVariable Long id, Model model){
        Album album=this.albumService.findById(id).orElseThrow(AlbumNotFound::new);
        model.addAttribute("album",album);
        List<Song>songs=album.getSongs();
        model.addAttribute("songs",songs);
        Artist artist=album.getArtist();
        model.addAttribute("artist",artist);
        return "album.html";
    }


    @GetMapping("/song/{id}")
    public String showSong(@PathVariable Long id, Model model){
        Song song=this.songServce.findById(id).orElseThrow(SongNotFound::new);
        model.addAttribute("song",song);
        String artist=song.getAlbum().getArtist().toString();
        model.addAttribute("artist",artist);
        return "song.html";
    }

    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        this.service.delete(id);
        return "redirect:/artists";
    }

    @GetMapping("/add-form")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String addArtistPage(Model model) {
        return "add-form.html";
    }

    @PostMapping("/add")
    public String create(@RequestParam String name,@RequestParam String url) {
        Artist artist=new Artist(name,url);
        this.service.save(artist);
        return "redirect:/artists";
    }

    @GetMapping("/edit-form/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String addArtistPage(@PathVariable Long id, Model model) {
        return "edit-form.html";
    }

    @DeleteMapping("/song/delete/{id}")
    public String deleteSong(@PathVariable Long id) {
        this.songServce.delete(id);
        Song song=this.songServce.findById(id).orElseThrow(SongNotFound::new);
        Long artist=song.getAlbum().getArtist().getId();
        return "redirect:/artists/"+artist;
    }


//    public String showAdd() {
//
//        return "";
//    }
//


//
//    public String update(Long id, String name, Double price, Integer quantity, List<Long> categories) {
//        this.service.update(id, name, price, quantity, categories);
//        return "";
//    }
//

}
