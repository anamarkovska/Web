package mk.ukim.finki.wp.exam.example.model;

import javax.persistence.*;

@Entity
public class Rating {

    public Rating() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private float rating;

    public float getRating() {
        return rating;
    }
}
