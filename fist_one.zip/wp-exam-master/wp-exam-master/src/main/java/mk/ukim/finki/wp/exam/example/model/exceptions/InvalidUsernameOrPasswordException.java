package mk.ukim.finki.wp.exam.example.model.exceptions;
public class InvalidUsernameOrPasswordException extends RuntimeException {
}
