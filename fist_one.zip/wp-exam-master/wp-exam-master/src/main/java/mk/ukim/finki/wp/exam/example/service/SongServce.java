package mk.ukim.finki.wp.exam.example.service;

import mk.ukim.finki.wp.exam.example.model.Song;

import java.util.List;
import java.util.Optional;

public interface SongServce {

    List<Song> findAllSongs();
    Optional<Song> findById(Long id);

    void delete(Long id);
}
